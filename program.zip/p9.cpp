#include<iostream>
using namespace std;
int main()
{
   int *ptr, arr[5], I;
   cout<<"Enter any five numbers:" ;
   for(int i=0; i<5; i++)
      cin>>arr[i];
   ptr = arr;
   for(int i=0; i<5; i++)
   {
      cout<<"\n\nptr = "<<*ptr;
      cout<<"\narr[�<<i<<�] = "<<arr[i];
      ptr++;
   }
   cout<<endl;
   return 0;
}
