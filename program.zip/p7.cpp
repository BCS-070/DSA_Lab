#include <iostream>

int main() {
    int numbers[] = {1, 2, 3, 4, 5};
    int* pointerToArray = numbers; // Initialize a pointer to the first element of the array

    std::cout << "Elements of the array using pointer:" << std::endl;
    for (int i = 0; i < 5; ++i) {
        std::cout << "Element " << i << ": " << *pointerToArray << std::endl;
        pointerToArray++; // Move the pointer to the next element
    }

    return 0;
}
