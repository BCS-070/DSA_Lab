#include<iostream>
using namespace std;
int main()
{
   int *ptr;
   int arr[5] = {10, 20, 30, 40, 50};
   ptr = arr;
   cout<<"ptr = "<<*ptr;
   cout<<"\narr[0] = <<arr[0]";
   cout<<endl;
   return 0;
}
