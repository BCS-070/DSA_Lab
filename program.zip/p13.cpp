#include <iostream>

int main() {
    int number = 42;
    int* pointerToNumber = &number; // Declare and initialize a pointer to an integer with the address of 'number'

    std::cout << "Value of number: " << number << std::endl;
    std::cout << "Address of number: " << &number << std::endl;
    std::cout << "Value of pointerToNumber: " << *pointerToNumber << std::endl;
    std::cout << "Address stored in pointerToNumber: " << pointerToNumber << std::endl;

    return 0;
}
